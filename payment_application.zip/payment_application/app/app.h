#ifndef APP_H_INCLUDED
#define APP_H_INCLUDED


#include "../server/server.h"
#include "../card/card.h"
#include "../terminal/terminal.h"

extern void appstart(void);

#endif


